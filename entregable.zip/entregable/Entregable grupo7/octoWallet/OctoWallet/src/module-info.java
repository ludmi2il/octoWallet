/**
 * 
 */
/**
 * 
 */
module OctoWallet {
}